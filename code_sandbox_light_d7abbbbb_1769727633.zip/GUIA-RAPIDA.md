# 🚀 Guía Rápida - SegurExpert Euskadi

## ¡Tu sitio web está listo!

### ✅ Lo que has conseguido:
- ✨ **Diseño profesional y elegante** con colores corporativos
- 📱 **Totalmente responsive** (funciona en móviles, tablets y ordenadores)
- 💼 **Secciones completas**: Inicio, Quiénes Somos, Servicios y Contacto
- 📧 **Formulario de contacto** funcional
- 🎨 **Animaciones suaves** y navegación fluida

---

## 🌐 Cómo publicar tu web (muy fácil)

### Paso 1: Haz clic en "Publish" (Publicar)
Busca la pestaña **"Publish"** en la parte superior de esta ventana y haz clic.

### Paso 2: Publica el proyecto
Haz clic en el botón **"Publish Project"** y espera unos segundos.

### Paso 3: ¡Ya está!
Recibirás una URL (dirección web) que podrás compartir con tus clientes. Por ejemplo:
- `https://tu-proyecto.example.com`

---

## 📧 Sobre el formulario de contacto

Cuando alguien rellena el formulario en tu web:
1. Se abrirá su programa de correo electrónico
2. El mensaje vendrá pre-rellenado con toda la información
3. Solo tendrá que hacer clic en "Enviar"
4. Tú recibirás el email en: **segurexpert.euskadi@gmail.com**

### 💡 Nota importante:
El formulario funciona abriendo el cliente de correo del visitante (Gmail, Outlook, etc.). Esto es lo mejor para una página web estática sin servidor.

---

## 🎨 Cómo personalizar la web

### Cambiar colores:
1. Abre el archivo `css/style.css`
2. En las primeras líneas verás los colores definidos
3. Cambia los valores hexadecimales (ejemplo: `#4a7ba7`)

### Cambiar textos:
1. Abre el archivo `index.html`
2. Busca el texto que quieras cambiar
3. Edítalo directamente
4. Guarda los cambios

### Añadir nuevas secciones:
1. Copia una sección existente en `index.html`
2. Modifica el contenido
3. Los estilos se aplicarán automáticamente

---

## 📱 Cómo añadir WhatsApp

Si quieres que los clientes te contacten por WhatsApp:

### Opción 1: Botón de WhatsApp
Añade este código antes de cerrar el `</body>` en `index.html`:

```html
<!-- WhatsApp Float Button -->
<a href="https://wa.me/34TUPHONENUMERO?text=Hola,%20me%20interesa%20contactar%20con%20SegurExpert%20Euskadi" 
   class="whatsapp-float" 
   target="_blank"
   aria-label="Contactar por WhatsApp">
    <i class="fab fa-whatsapp"></i>
</a>
```

**Importante**: Reemplaza `34TUPHONENUMERO` por tu número de teléfono completo (con código de país, sin espacios ni guiones).

Ejemplo: Si tu número es 612 345 678, pon: `34612345678`

### Opción 2: Botón en el formulario
Puedes añadir un botón de WhatsApp al lado del formulario para dar otra opción de contacto.

---

## 📊 Próximos pasos recomendados

### 1. **SEO Básico** (para aparecer en Google)
- Registra tu web en Google Search Console
- Añade tu negocio en Google My Business
- Comparte tu web en redes sociales

### 2. **Contenido adicional**
- Añadir testimonios de clientes
- Crear un blog con artículos de seguridad
- Galería de proyectos realizados

### 3. **Marketing**
- Compartir la web en LinkedIn
- Incluir la URL en tarjetas de visita
- Email signature con link a la web

---

## ❓ Preguntas Frecuentes

### ¿Necesito pagar por algo?
No, la web funciona completamente. Solo necesitarías pagar si quieres:
- Un dominio propio (ejemplo: segurexpert-euskadi.com)
- Hosting premium
- Certificado SSL (aunque muchos hostings lo dan gratis)

### ¿Puedo editar la web yo mismo?
Sí, todos los archivos son editables:
- `index.html` → Para cambiar textos
- `css/style.css` → Para cambiar colores y estilos
- `js/main.js` → Para cambiar funcionalidades

### ¿Funciona en móviles?
¡Sí! La web está optimizada para verse perfectamente en:
- 📱 Teléfonos móviles
- 📱 Tablets
- 💻 Ordenadores portátiles
- 🖥️ Ordenadores de escritorio

### ¿Cómo actualizo el contenido?
1. Edita los archivos que necesites
2. Guarda los cambios
3. Vuelve a publicar desde la pestaña "Publish"

---

## 📞 Información de Contacto en tu Web

- **Email**: segurexpert.euskadi@gmail.com
- **Ubicación**: País Vasco, España
- **Servicios**: Gestión de Riesgos, Planes de Emergencia, Planes de Autoprotección, Consultoría en Seguridad

---

## 🎉 ¡Felicidades!

Tu web profesional ya está lista para usar. Solo falta:
1. Publicarla (pestaña Publish)
2. Compartir la URL con tus clientes
3. Empezar a recibir consultas

¡Mucha suerte con **SegurExpert Euskadi**! 🛡️

---

## 💡 Consejo final

No te preocupes si no eres experto en ordenadores. La web está diseñada para ser:
- **Fácil de usar**
- **Fácil de mantener**
- **Fácil de compartir**

Si necesitas ayuda, todos los archivos están bien documentados y puedes buscar tutoriales sobre HTML y CSS (son muy sencillos de aprender).

**¡Éxito con tu negocio!** 🚀